package com.suivi.frigo.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.suivi.frigo.R
import com.suivi.frigo.ble.ConnectionState
import com.suivi.frigo.ble.FridgeBleManager
import com.suivi.frigo.ble.FridgeStatus
import com.suivi.frigo.data.FridgeDatabase
import com.suivi.frigo.data.FridgeReading
import com.suivi.frigo.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Service au premier plan : tant qu'il tourne, l'app reste connectée au frigo
 * (même écran verrouillé) et chaque trame de statut reçue est immédiatement
 * insérée en base avec son horodatage.
 */
class FridgeMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "fridge_monitor_channel"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "com.suivi.frigo.action.START"
        const val ACTION_STOP = "com.suivi.frigo.action.STOP"

        // Dernier statut connu, observable depuis l'UI sans repasser par la base
        val latestStatus = androidx.lifecycle.MutableLiveData<FridgeStatus?>(null)
        val connectionState = androidx.lifecycle.MutableLiveData(ConnectionState.DISCONNECTED)
    }

    private lateinit var bleManager: FridgeBleManager
    private lateinit var db: FridgeDatabase
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    override fun onCreate() {
        super.onCreate()
        db = FridgeDatabase.getInstance(applicationContext)
        bleManager = FridgeBleManager(applicationContext)
        bleManager.autoReconnect = true

        bleManager.listener = object : FridgeBleManager.Listener {
            override fun onStateChanged(state: ConnectionState) {
                connectionState.postValue(state)
                updateNotification(state)
            }

            override fun onStatusReceived(status: FridgeStatus) {
                latestStatus.postValue(status)
                serviceScope.launch {
                    db.fridgeReadingDao().insert(
                        FridgeReading(
                            timestamp = System.currentTimeMillis(),
                            tempSet = status.tempSet,
                            fridgeTemp = status.fridgeTemp,
                            batteryPct = status.batteryPct,
                            voltage = status.voltage,
                            locked = status.locked,
                            on = status.on,
                            ecoMode = status.ecoMode
                        )
                    )
                    // Purge des données de plus de 72h pour ne pas faire grossir la base
                    val cutoff = System.currentTimeMillis() - 72L * 60 * 60 * 1000
                    db.fridgeReadingDao().deleteOlderThan(cutoff)
                }
            }

            override fun onDeviceFound(name: String, address: String) {
                // Rien de spécial à faire ici : la connexion s'enchaîne automatiquement
            }
        }

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                bleManager.disconnect()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification(ConnectionState.SCANNING))
                bleManager.autoReconnect = true
                bleManager.startScan()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        bleManager.disconnect()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(state: ConnectionState): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val text = when (state) {
            ConnectionState.CONNECTED -> getString(R.string.notif_text_connected)
            else -> getString(R.string.notif_text_searching)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(state: ConnectionState) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(state))
    }
}
