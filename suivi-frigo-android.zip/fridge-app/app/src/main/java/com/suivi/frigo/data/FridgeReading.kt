package com.suivi.frigo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Un point de mesure du frigo, horodaté, stocké en base locale.
 * Chaque fois qu'on reçoit une trame de statut valide du frigo, on insère une ligne.
 */
@Entity(tableName = "fridge_readings")
data class FridgeReading(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    // Horodatage en millisecondes depuis epoch (System.currentTimeMillis())
    val timestamp: Long,

    val tempSet: Int,
    val fridgeTemp: Int,
    val batteryPct: Int,
    val voltage: Double,
    val locked: Boolean,
    val on: Boolean,
    val ecoMode: Boolean
)
