package com.suivi.frigo.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.util.Log

enum class ConnectionState {
    DISCONNECTED, SCANNING, CONNECTING, CONNECTED
}

/**
 * Encapsule toute la logique BLE : recherche du frigo par son service UUID,
 * connexion, abonnement aux notifications de statut, envoi périodique du Ping,
 * et reconnexion automatique en cas de coupure.
 */
class FridgeBleManager(private val context: Context) {

    companion object {
        private const val TAG = "FridgeBleManager"
        private const val PING_INTERVAL_MS = 3000L
        private const val SCAN_TIMEOUT_MS = 20000L
        private const val RECONNECT_DELAY_MS = 4000L
    }

    interface Listener {
        fun onStateChanged(state: ConnectionState)
        fun onStatusReceived(status: FridgeStatus)
        fun onDeviceFound(name: String, address: String)
    }

    var listener: Listener? = null
    var autoReconnect: Boolean = true

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager.adapter

    private var gatt: BluetoothGatt? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pingRunnable: Runnable? = null
    private var lastKnownAddress: String? = null

    var state: ConnectionState = ConnectionState.DISCONNECTED
        private set(value) {
            field = value
            listener?.onStateChanged(value)
        }

    @SuppressLint("MissingPermission")
    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner ?: run {
            Log.w(TAG, "Bluetooth non disponible ou désactivé")
            return
        }
        state = ConnectionState.SCANNING

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(FridgeProtocol.SERVICE_UUID))
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanner.startScan(listOf(filter), settings, scanCallback)

        mainHandler.postDelayed({
            if (state == ConnectionState.SCANNING) {
                scanner.stopScan(scanCallback)
                state = ConnectionState.DISCONNECTED
            }
        }, SCAN_TIMEOUT_MS)
    }

    @SuppressLint("MissingPermission")
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = device.name ?: return
            if (!name.startsWith("A1-")) return

            listener?.onDeviceFound(name, device.address)
            adapter?.bluetoothLeScanner?.stopScan(this)
            connectToDevice(device)
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "Scan échoué, code=$errorCode")
            state = ConnectionState.DISCONNECTED
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToAddress(address: String) {
        val device = adapter?.getRemoteDevice(address) ?: return
        connectToDevice(device)
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(device: BluetoothDevice) {
        lastKnownAddress = device.address
        state = ConnectionState.CONNECTING
        gatt = device.connectGatt(context, false, gattCallback)
    }

    @SuppressLint("MissingPermission")
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    g.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    stopPing()
                    state = ConnectionState.DISCONNECTED
                    g.close()
                    if (gatt == g) gatt = null
                    if (autoReconnect) {
                        mainHandler.postDelayed({ attemptReconnect() }, RECONNECT_DELAY_MS)
                    }
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val service = g.getService(FridgeProtocol.SERVICE_UUID) ?: return
            val notifyChar = service.getCharacteristic(FridgeProtocol.NOTIFY_UUID) ?: return

            g.setCharacteristicNotification(notifyChar, true)
            val descriptor = notifyChar.descriptors.firstOrNull()
            if (descriptor != null) {
                descriptor.value = BluetoothGattDescriptorValues.ENABLE_NOTIFICATION_VALUE
                g.writeDescriptor(descriptor)
            }

            state = ConnectionState.CONNECTED
            startPing(g, service)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            val bytes = characteristic.value ?: return
            FridgeProtocol.parseStatus(bytes)?.let { status ->
                listener?.onStatusReceived(status)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startPing(g: BluetoothGatt, service: android.bluetooth.BluetoothGattService) {
        val writeChar = service.getCharacteristic(FridgeProtocol.WRITE_UUID) ?: return
        stopPing()
        pingRunnable = object : Runnable {
            override fun run() {
                writeChar.value = FridgeProtocol.PING_CMD
                writeChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                g.writeCharacteristic(writeChar)
                mainHandler.postDelayed(this, PING_INTERVAL_MS)
            }
        }
        mainHandler.post(pingRunnable!!)
    }

    private fun stopPing() {
        pingRunnable?.let { mainHandler.removeCallbacks(it) }
        pingRunnable = null
    }

    private fun attemptReconnect() {
        val address = lastKnownAddress
        if (address != null) {
            connectToAddress(address)
        } else {
            startScan()
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        autoReconnect = false
        stopPing()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        state = ConnectionState.DISCONNECTED
    }
}

/**
 * Petit objet utilitaire pour la valeur standard du descripteur CCCD
 * (évite de dépendre de BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE qui est deprecated
 * sur certaines API mais reste la valeur standard BLE 0x0100).
 */
private object BluetoothGattDescriptorValues {
    val ENABLE_NOTIFICATION_VALUE: ByteArray = byteArrayOf(0x01, 0x00)
}
