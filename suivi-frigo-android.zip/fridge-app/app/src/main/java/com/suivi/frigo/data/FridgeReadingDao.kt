package com.suivi.frigo.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FridgeReadingDao {

    @Insert
    suspend fun insert(reading: FridgeReading)

    // Tous les points depuis un instant donné (pour les fenêtres 12h/24h/48h/72h),
    // triés du plus ancien au plus récent pour le tracé du graphique.
    @Query("SELECT * FROM fridge_readings WHERE timestamp >= :sinceMillis ORDER BY timestamp ASC")
    fun observeSince(sinceMillis: Long): LiveData<List<FridgeReading>>

    @Query("SELECT * FROM fridge_readings ORDER BY timestamp DESC LIMIT 1")
    fun observeLatest(): LiveData<FridgeReading?>

    @Query("SELECT * FROM fridge_readings WHERE timestamp >= :sinceMillis ORDER BY timestamp ASC")
    suspend fun getSince(sinceMillis: Long): List<FridgeReading>

    // Nettoyage : on garde au maximum 72h d'historique pour ne pas faire grossir
    // la base indéfiniment (l'app ne propose pas de vue au-delà de 72h).
    @Query("DELETE FROM fridge_readings WHERE timestamp < :beforeMillis")
    suspend fun deleteOlderThan(beforeMillis: Long)
}
