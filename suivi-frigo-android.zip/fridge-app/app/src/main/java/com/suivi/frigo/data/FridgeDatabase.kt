package com.suivi.frigo.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [FridgeReading::class], version = 1, exportSchema = false)
abstract class FridgeDatabase : RoomDatabase() {

    abstract fun fridgeReadingDao(): FridgeReadingDao

    companion object {
        @Volatile
        private var INSTANCE: FridgeDatabase? = null

        fun getInstance(context: Context): FridgeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FridgeDatabase::class.java,
                    "fridge_history.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
