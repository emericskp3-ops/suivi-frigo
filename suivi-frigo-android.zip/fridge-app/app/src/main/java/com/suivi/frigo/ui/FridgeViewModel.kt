package com.suivi.frigo.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import com.suivi.frigo.data.FridgeDatabase
import com.suivi.frigo.data.FridgeReading

enum class Period(val hours: Int, val label: String) {
    H12(12, "12h"),
    H24(24, "24h"),
    H48(48, "48h"),
    H72(72, "72h")
}

class FridgeViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = FridgeDatabase.getInstance(application).fridgeReadingDao()

    private val selectedPeriod = MutableLiveData(Period.H24)

    val period: LiveData<Period> = selectedPeriod

    // Recalcule automatiquement la requête Room dès que la période change.
    val history: LiveData<List<FridgeReading>> = selectedPeriod.switchMap { p ->
        val since = System.currentTimeMillis() - p.hours * 60L * 60L * 1000L
        dao.observeSince(since)
    }

    val latest: LiveData<FridgeReading?> = dao.observeLatest()

    fun setPeriod(p: Period) {
        selectedPeriod.value = p
    }
}
