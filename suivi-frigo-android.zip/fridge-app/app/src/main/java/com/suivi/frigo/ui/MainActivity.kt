package com.suivi.frigo.ui

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.suivi.frigo.R
import com.suivi.frigo.ble.ConnectionState
import com.suivi.frigo.data.FridgeReading
import com.suivi.frigo.databinding.ActivityMainBinding
import com.suivi.frigo.service.FridgeMonitorService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: FridgeViewModel
    private var serviceRunning = false

    private val periodButtons by lazy {
        mapOf(
            Period.H12 to binding.btn12h,
            Period.H24 to binding.btn24h,
            Period.H48 to binding.btn48h,
            Period.H72 to binding.btn72h
        )
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startMonitoring()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[FridgeViewModel::class.java]

        setupChart()
        setupPeriodButtons()

        binding.btnConnect.setOnClickListener {
            if (serviceRunning) stopMonitoring() else requestPermissionsAndStart()
        }

        FridgeMonitorService.connectionState.observe(this) { state ->
            updateConnectionUi(state)
        }

        FridgeMonitorService.latestStatus.observe(this) { status ->
            status ?: return@observe
            binding.tvVoltage.text = "${status.voltage} V"
            binding.tvBatteryPct.text = "${status.batteryPct}%"
            binding.progressBattery.progress = status.batteryPct
            binding.tvFridgeTemp.text = "${status.fridgeTemp}°C"
            binding.tvTempSet.text = "${status.tempSet}°C"

            val batteryColor = when {
                status.batteryPct >= 60 -> ContextCompat.getColor(this, R.color.battery_good)
                status.batteryPct >= 30 -> ContextCompat.getColor(this, R.color.battery_mid)
                else -> ContextCompat.getColor(this, R.color.battery_low)
            }
            binding.tvBatteryPct.setTextColor(batteryColor)

            binding.badgePower.text = if (status.on) "●  Marche" else "●  Arrêt"
            binding.badgeEco.text = if (status.ecoMode) "🌿 Eco actif" else "Eco inactif"
            binding.badgeLock.text = if (status.locked) "🔒 Verrouillé" else "🔓 Déverrouillé"
        }

        viewModel.history.observe(this) { readings ->
            updateChart(readings)
        }

        viewModel.period.observe(this) { p ->
            highlightSelectedPeriod(p)
        }
    }

    private fun setupPeriodButtons() {
        periodButtons.forEach { (period, view) ->
            view.setOnClickListener { viewModel.setPeriod(period) }
        }
        highlightSelectedPeriod(Period.H24)
    }

    private fun highlightSelectedPeriod(selected: Period) {
        periodButtons.forEach { (period, view) ->
            view.setBackgroundResource(
                if (period == selected) R.drawable.period_selected_bg else 0
            )
        }
    }

    private fun updateConnectionUi(state: ConnectionState) {
        val (textRes, colorRes) = when (state) {
            ConnectionState.CONNECTED -> R.string.status_connected to R.color.battery_good
            ConnectionState.SCANNING, ConnectionState.CONNECTING ->
                R.string.status_searching to R.color.accent_amber
            ConnectionState.DISCONNECTED -> R.string.status_disconnected to R.color.text_disabled
        }
        binding.tvConnectionStatus.setText(textRes)
        binding.dotStatus.setBackgroundColor(ContextCompat.getColor(this, colorRes))

        serviceRunning = state != ConnectionState.DISCONNECTED
        binding.btnConnect.setText(
            if (serviceRunning) R.string.btn_disconnect else R.string.btn_connect
        )
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions += Manifest.permission.BLUETOOTH_SCAN
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            permissions += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun startMonitoring() {
        val intent = Intent(this, FridgeMonitorService::class.java).apply {
            action = FridgeMonitorService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopMonitoring() {
        val intent = Intent(this, FridgeMonitorService::class.java).apply {
            action = FridgeMonitorService.ACTION_STOP
        }
        startService(intent)
    }

    // ---- Graphique ----

    private fun setupChart() {
        val chart = binding.chart
        chart.description.isEnabled = false
        chart.legend.textColor = Color.parseColor("#8FA6A8")
        chart.setNoDataText("Aucune donnée encore — connecte le frigo")
        chart.setNoDataTextColor(Color.parseColor("#52666A"))
        chart.setBackgroundColor(Color.TRANSPARENT)
        chart.setDrawGridBackground(false)

        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            textColor = Color.parseColor("#8FA6A8")
            setDrawGridLines(false)
            granularity = 1f
        }
        chart.axisLeft.apply {
            textColor = Color.parseColor("#8FA6A8")
            gridColor = Color.parseColor("#243944")
        }
        chart.axisRight.isEnabled = true
        chart.axisRight.textColor = Color.parseColor("#F2A93B")
    }

    private fun updateChart(readings: List<FridgeReading>) {
        val chart = binding.chart
        if (readings.isEmpty()) {
            chart.clear()
            chart.invalidate()
            return
        }

        val voltageEntries = readings.mapIndexed { i, r -> Entry(i.toFloat(), r.voltage.toFloat()) }
        val tempEntries = readings.mapIndexed { i, r -> Entry(i.toFloat(), r.fridgeTemp.toFloat()) }

        val voltageSet = LineDataSet(voltageEntries, "Tension (V)").apply {
            color = Color.parseColor("#3DDCC9")
            setCircleColor(Color.parseColor("#3DDCC9"))
            circleRadius = 1.5f
            lineWidth = 2f
            setDrawValues(false)
            axisDependency = YAxis.AxisDependency.LEFT
            setDrawCircles(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        val tempDataSet = LineDataSet(tempEntries, "Température (°C)").apply {
            color = Color.parseColor("#F2A93B")
            circleRadius = 1.5f
            lineWidth = 2f
            setDrawValues(false)
            axisDependency = YAxis.AxisDependency.RIGHT
            setDrawCircles(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        chart.data = LineData(voltageSet, tempDataSet)

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        chart.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                if (index < 0 || index >= readings.size) return ""
                return timeFormat.format(Date(readings[index].timestamp))
            }
        }
        // Limiter le nombre de labels affichés pour rester lisible
        chart.xAxis.labelCount = 6

        chart.invalidate()
    }
}
